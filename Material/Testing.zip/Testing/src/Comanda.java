import java.util.*;

 enum Estado{CREANDO, CREADO, MODIFICADO,PAGADO};


public class Comanda {
	
	
	
	public List <Plato> platos = new ArrayList <Plato>();
	public List <Bebida> bebidas = new ArrayList <Bebida>();
	public Estado estado;
	public float precioTotal = 0;
	public Date fecha;
	
	
	public Comanda()
	{
		this.estado = Estado.CREANDO;
	}
	
	public void anadir_Plato(Plato p) {
		
		p.disponible();
		
		if(p.disponible) {
			this.platos.add(p);
			p.pedir_plato();
			this.precioTotal+=p.precio;
		}else {
			
			System.out.println("Plato no disponible.");
		}
		
		
	}
	
	public void anadir_Bebida(Bebida b) {
		
		this.bebidas.add(b);
		this.precioTotal+=b.precio;
		
	}
	
	public void anadir_MD(MenuDia md) {
		
		this.platos.add(md.primero);
		this.platos.add(md.segundo);
		this.platos.add(md.postre);
		this.precioTotal+=md.precio;
	}
	
	public void confirmar_comanda() {
		
		if(estado == Estado.CREADO) {
			
			this.estado = Estado.MODIFICADO;
		}else {
			
			this.estado = Estado.CREADO;
		}	
	}
	
	public void modificar_comanda(Plato p){				//Metodo para modificar plato ya elegido;
		
		if(p.estado == Estado_Plato.En_espera) {
			
			System.out.println("Puedes modificar plato.");
			
		}
		
		
		
		
	}

	
}
