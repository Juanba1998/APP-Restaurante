import java.util.*;

public class Comanda {
	public List <Plato> platos = new ArrayList <Plato>();
	public List <Bebida> bebidas = new ArrayList <Bebida>();
	public float precioTotal;
	public Date fecha;
	
	public Comanda(List <Plato> p, List <Bebida> b)
	{
		this.platos = p;
		this.bebidas = b;
		this.precioTotal = calcularPrecio();
		this.fecha = new Date();
	}
	
	public Comanda(MenuDia m, List <Bebida> b)
	{
		this.platos.add(m.primero);
		this.platos.add(m.segundo);
		this.platos.add(m.postre);
		this.bebidas = b;
		this.precioTotal = calcularPrecio();
		this.fecha = new Date();
	}

	private float calcularPrecio() {
		float precio = 0;
		for (Plato p: platos)
		{
			precio+=p.precio;
		}
		
		for (Bebida b: bebidas)
		{
			precio+=b.precio;
		}
		return precio;
	}
}
