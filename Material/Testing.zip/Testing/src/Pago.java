import java.util.*;

public class Pago {
	public float pagoTotal;
	public int numeroTarjeta;
	public String titularTarjeta;
	public Comanda c;
	public Date fecha_pago;
	public Date fecha_comanda;
	
	public Pago(Comanda c, int numeroTarjeta, String titularTarjeta)
	{
		this.c = c;
		this.pagoTotal = c.precioTotal;
		this.numeroTarjeta = numeroTarjeta;
		this.titularTarjeta = titularTarjeta;
		this.fecha_pago = new Date();
		this.fecha_comanda = c.fecha;
	}
	public Pago(float pagoTotal)
	{
		this.pagoTotal = pagoTotal;
		this.fecha_pago = new Date();
		this.fecha_comanda = c.fecha;
		LlamarCamarero();
	}
	private void LlamarCamarero() {
	}
}
