import java.util.ArrayList;
import java.util.List;

public class Prueba {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Ingrediente.alergeno> alg_harina = new ArrayList<Ingrediente.alergeno>();
		List<Ingrediente.alergeno> alg_huevo = new ArrayList<Ingrediente.alergeno>();
		List<Ingrediente.alergeno> alg_leche = new ArrayList<Ingrediente.alergeno>();
		List<Ingrediente.alergeno> alg_pescado = new ArrayList<Ingrediente.alergeno>();

		alg_harina.add(Ingrediente.alergeno.cereales);
		alg_huevo.add(Ingrediente.alergeno.huevo);
		alg_leche.add(Ingrediente.alergeno.lacteos);
		alg_pescado.add(Ingrediente.alergeno.pescado);
		
		Ingrediente harina = new Ingrediente("Harina", alg_harina);
		Ingrediente huevo = new Ingrediente("Huevo", alg_huevo);
		Ingrediente leche = new Ingrediente("Leche", alg_leche);
		Ingrediente atun = new Ingrediente("At�n", alg_pescado);
		Ingrediente mantequilla = new Ingrediente("Mantequilla", alg_leche);
		Ingrediente pan = new Ingrediente ("Pan", alg_harina);
		
		List<Ingrediente> ing_croquetas = new ArrayList<Ingrediente>();
		
		ing_croquetas.add(harina);
		ing_croquetas.add(huevo);
		ing_croquetas.add(atun);
		ing_croquetas.add(leche);
		ing_croquetas.add(mantequilla);
		ing_croquetas.add(pan);
		
		Plato croqueta = new Plato("Croqueta",10, ing_croquetas);
		
		croqueta.print();
		
		
		
		
			
	}

}
