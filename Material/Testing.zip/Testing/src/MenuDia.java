public class MenuDia {
	public Plato[] primerPlato;
	public Plato[] segundoPlato;
	public Plato[] postres;
	public Plato primero;
	public Plato segundo;
	public Plato postre;
	public float precio;
	
	public MenuDia(float precio, Plato[] primeros, Plato[] segundos, Plato[] postres)
	{
		this.primerPlato = primeros;
		this.segundoPlato = segundos;
		this.postres = postres;
		this.precio = precio;
	}
}
