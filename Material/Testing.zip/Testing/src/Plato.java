import java.util.*;
enum Estado_Plato{En_espera, En_preparaci�n, En_camino, Entregado}

public class Plato {
	public Estado_Plato estado;
	public boolean disponible;
	private String nombre;
	public float precio;
	private List <Ingrediente> ingFijos = new ArrayList <Ingrediente>();
	private List <Ingrediente> ingVariables = new ArrayList <Ingrediente>();
	
	public Plato(String nombre, float precio, List <Ingrediente> ing)
	{
		this.nombre = nombre;
		this.precio = precio;
		this.ingFijos = ing;
		
	}
	
	public Plato(String nombre, float precio, List <Ingrediente> ingFijos, List <Ingrediente> ingVariables)
	{
		this.nombre = nombre;
		this.precio = precio;
		this.ingFijos = ingFijos;
		this.ingVariables = ingVariables;
	
	}
	
	public void pedir_plato() {
		
		this.estado = Estado_Plato.En_espera;
	}
	
	public void cocinar_plato() {
		
		this.estado = Estado_Plato.En_preparaci�n;
	}
	
	public void llevar_plato() {
		
		this.estado = Estado_Plato.En_camino;
	}
	
	public void entregar_plato() {
		
		this.estado = Estado_Plato.Entregado;
	}
	
	public void disponible() {
		
		boolean b = true;
		
		Iterator <Ingrediente> it = ingFijos.iterator();
		
		while(b&&it.hasNext()) {
			
			if(!it.next().disponible) {
				
				b=false;
			}
		}
		
		Iterator <Ingrediente> it2 = ingVariables.iterator();
		
		while(b&&it2.hasNext()) {
			
			if(!it2.next().disponible) {
				
				b=false;
			}
		}
		
		this.disponible=b;
		
	}
	
	public void print() {
		
		System.out.println("Nombre: " +nombre);
		System.out.println("Ingredientes fijos: " );
		
		Iterator<Ingrediente> itf = ingFijos.iterator();
		
		while(itf.hasNext()) {
			
			itf.next().print();
		}
		
		System.out.println("Ingredientes Variables: " );
		
		Iterator<Ingrediente> itv = ingFijos.iterator();
		
		while(itv.hasNext()) {
			
			itv.next().print();
		}
		
	}
}
