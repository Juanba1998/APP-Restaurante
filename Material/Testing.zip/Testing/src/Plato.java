import java.util.*;

public class Plato {
	private enum estado{En_espera, En_preparaci�n, En_camino};
	private boolean disponible;
	private String nombre;
	public float precio;
	private List <Ingrediente> ingFijos = new ArrayList <Ingrediente>();
	private List <Ingrediente> ingVariables = new ArrayList <Ingrediente>();
	
	public Plato(String nombre, float precio, List <Ingrediente> ing)
	{
		this.nombre = nombre;
		this.precio = precio;
		this.ingFijos = ing;
	}
	
	public Plato(String nombre, float precio, List <Ingrediente> ingFijos, List <Ingrediente> ingVariables)
	{
		this.nombre = nombre;
		this.precio = precio;
		this.ingFijos = ingFijos;
		this.ingVariables = ingVariables;
	}
}
