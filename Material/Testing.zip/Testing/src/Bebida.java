import java.util.ArrayList;
import java.util.List;

public class Bebida {
	private boolean estado;
	private String nombre;
	public float precio;
	private List <Ingrediente> ing = new ArrayList <Ingrediente>();
	
	public Bebida(String nombre, float precio, List <Ingrediente> ing)
	{
		this.nombre = nombre;
		this.precio = precio;
		this.ing = ing;
	}
}