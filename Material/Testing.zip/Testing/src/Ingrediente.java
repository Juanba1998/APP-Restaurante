import java.util.ArrayList;
import java.util.List;

public class Ingrediente {
	public String nombre;
	public enum alergeno{pescado, frutos_secos, lacteos, huevo, cereales};
	private List <alergeno> alergenos = new ArrayList <alergeno>();
	
	public Ingrediente(String nombre, List alergenos)
	{
		this.nombre = nombre;
		this.alergenos = alergenos;
	}
}
