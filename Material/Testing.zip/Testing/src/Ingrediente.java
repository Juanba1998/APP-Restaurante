import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Ingrediente {
	public String nombre;
	public enum alergeno{pescado, frutos_secos, lacteos, huevo, cereales};
	private List <alergeno> alergenos = new ArrayList <alergeno>();
	public int cantidad;
	public boolean disponible;
	
	public Ingrediente(String nombre, List<alergeno> alg)
	{
		this.nombre = nombre;
		this.alergenos = alg;
		reponer();
		
	}
	
	public void reponer () {
		
		
		this.disponible = true;
	}
	
	public void agotado() {
		
		this.disponible=false;
	}
	
	
	public void print() {
		
		System.out.println("Ingrediente: "+nombre);
		System.out.println("Alergenos: ");
		
		Iterator<alergeno> it =alergenos.iterator();
		
		while(it.hasNext()) {
			
			System.out.println("		* " +it.next().toString());
			
			
		}
	}
	

	
	
}
